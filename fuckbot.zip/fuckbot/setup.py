import os
os.system("sudo pip install discord")
os.system("sudo pip install ping3")
os.system("sudo pip install aiohttp")
os.system("sudo pip install asyncio")
os.system("sudo pip install random")
os.system("sudo pip install requests")
os.system("sudo pip install psutil")
os.system("sudo pip install threading")
os.system("sudo pip install axios")
os.system("sudo pip install fake-useragent")
os.system("sudo pip install cluster")
os.system("pip install fs")
os.system("pip install net")
os.system("pip install cloudscraper")
os.system("pip install path")



